package miniproject;
import java.sql.*;
import java.util.Scanner;

public class Studentprogram {

    static Connection con;

    static String IsPaid(int tuitionFee, int balanceAmount){
        if(tuitionFee > balanceAmount){
            return "Unpaid";
        }
        return "Paid";        
    }
	
    static void ConnectDB(){
    	try {
			 Class.forName("com.mysql.jdbc.Driver");
			 
			 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentsystem","root","vamsikalyan@2000");

             System.out.println("Connection Successful");
			 
		}
		  catch(Exception e)
	    {
	      System.out.println(e);
	    }
        
    }

    static void DisconnectDB(){
        try{
            con.close();
        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    static int GenerateStudentID(){
        int StudentId = 10000;
        try{
            
            String Query = "select * from student order by StudentId desc";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            if(rs.next()){
                StudentId = Integer.parseInt(rs.getString(1));
            }

        }
        catch(Exception e){
            System.out.println(e);
        }
        return StudentId+1;
    }

    static void Enroll(int StudentId, String StudentName, String CourseName){
        int TuitionFee = 50000;
        int BalanceAmount = 10000;
        String Paid = "Unpaid";
        try{

            String Query = String.format("insert into student values (%d,'%s','%s',%d,%d,'%s');", StudentId, StudentName, CourseName, TuitionFee, BalanceAmount, Paid);
            Statement st=con.createStatement();
			st.executeUpdate(Query);

            System.out.println("Successfully Record Created");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    static void Enroll(int StudentId, String StudentName, String CourseName, int TuitionFee, int BalanceAmount, String Paid){
        try{

            String Query = String.format("insert into student values (%d,'%s','%s',%d,%d,'%s');", StudentId, StudentName, CourseName, TuitionFee, BalanceAmount, Paid);
            Statement st=con.createStatement();
			st.executeUpdate(Query);

            System.out.println("Successfully Record Created");
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
	
    static void PayTuitionFees(String StudentName, int Amount){

        try{

            String Total;
            String Balance;

            String Query1 = String.format("select * from student where StudentName = '%s'", StudentName);
            Statement st1 = con.createStatement();
            ResultSet rs = st1.executeQuery(Query1);
            if (rs.next()) {
                Total = rs.getString(4);
                Balance = rs.getString(5);

                int Pending = Integer.parseInt(Balance)-Amount;

                String Query2 = String.format("update student set BalanceAmount = %d, Paid = '%s' where StudentName = '%s';", Pending, IsPaid(Integer.parseInt(Balance), Amount), StudentName);
                Statement st2=con.createStatement();
                st2.executeUpdate(Query2);
            }

            System.out.println("Payment Successful");
        }
        catch(Exception e){
            System.out.println(e);
        }        

    }

    static void PayTuitionFees(int StudentId, int Amount){

        try{

            String Total;
            String Balance;

            String Query1 = String.format("select * from student where StudentId = %d", StudentId);
            Statement st1 = con.createStatement();
            ResultSet rs = st1.executeQuery(Query1);
            if (rs.next()) {
                Total = rs.getString(4);
                Balance = rs.getString(5);

                int Pending = Integer.parseInt(Balance)-Amount;

                String Query2 = String.format("update student set BalanceAmount = %d, Paid = '%s' where StudentId = %d;", Pending, IsPaid(Integer.parseInt(Total), Amount));
                Statement st2=con.createStatement();
                st2.executeUpdate(Query2);
            }

            System.out.println("Payment Successful");
        }
        catch(Exception e){
            System.out.println(e);
        }        

    }

    static void ViewBalance(){
        try{
            String Query = "select * from student;";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            System.out.println("Student ID     ||      Student Name      ||       Balance Amount");
            while (rs.next()) {
                System.out.println(rs.getString(1) + "||" +rs.getString(2) + "||" + rs.getString(5));
            }

        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    static void ViewBalance(String StudentName){
        try{
            String Query = String.format("select * from student where StudentName = '%s'", StudentName);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            if (rs.next()) {
                System.out.println(rs.getString(1) + "||" +rs.getString(2) + "||" + rs.getString(5));   
            }

        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    static void ViewBalance(int StudentId){
        try{
            String Query = String.format("select * from student where StudentId = %d", StudentId);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            if (rs.next()) {
                System.out.println(rs.getString(1) + "||" +rs.getString(2) + "||" + rs.getString(5));   
            }

        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    static void ShowStatus(){
        try{
            String Query = "select * from student";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            while (rs.next()) {
                System.out.println(rs.getString(1) + "||" +rs.getString(2) + "||" + rs.getString(6));
            }

        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    static void ShowStatus(String StudentName){
        try{
            String Query = String.format("select * from student where StudentName = '%s'", StudentName);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            if (rs.next()) {
                System.out.println(rs.getString(1) + "||" +rs.getString(2) + "||" + rs.getString(6));
            }

        }
        catch(Exception e){
            System.out.println(e);
        }
    }

    static void ShowStatus(int StudentId){
        try{
            String Query = String.format("select * from student where StudentId = %d", StudentId);
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(Query);
            if (rs.next()) {
                System.out.println(rs.getString(1) + "||" +rs.getString(2) + "||" + rs.getString(6));
            }

        }
        catch(Exception e){
            System.out.println(e);
        }
    }




    public static void main(String[] args) {
    	
        //DATABASE CONNECTION
    	ConnectDB();
        

        //INPUT
        System.out.println("Welcome to Student Management System App");
        Scanner sc=new Scanner(System.in);


        int option;
        String StudentName;
        String CourseName;
        int Amount;
        


        loop : while (true) {
            
            System.out.println("Choose an option from the following to perform the operation");
            System.out.println("1) Enroll");
            System.out.println("2) View Balance");
            System.out.println("3) Pay tuition Fees");
            System.out.println("4) Show Status");
            System.out.println("Any other number to cancel");

            option = sc.nextInt();            

            switch (option) {
                case 1:
                    System.out.print("Enter Student Name  : ");
                    StudentName = sc.next();
                    System.out.print("Enter Course Name :");
                    CourseName = sc.next();
                    Enroll(GenerateStudentID(), StudentName, CourseName);
                    break;

                case 2:
                    System.out.print("Enter Student Name or Student ID : ");
                    StudentName = sc.next();
                    if(StudentName.compareTo("") == 0){
                        ViewBalance();
                    }
                    else if(Character.isDigit(StudentName.charAt(0))){
                        ViewBalance(Integer.parseInt(StudentName));
                    }else{
                        ViewBalance(StudentName);
                    }
                    break;


                case 3:
                    System.out.print("Enter Student Name or Student ID : ");
                    StudentName = sc.next();
                    System.out.print("Enter Amount to Pay : ");
                    Amount = sc.nextInt();
                    if(Character.isDigit(StudentName.charAt(0))){
                        PayTuitionFees(Integer.parseInt(StudentName), Amount);
                    }else{
                        PayTuitionFees(StudentName, Amount);
                    }
                    break;

                case 4:
                    System.out.print("Enter Student Name or Student ID: ");
                    StudentName = sc.next();
                    if(StudentName.compareTo("") == 0){
                        ShowStatus();
                    } else if(Character.isDigit(StudentName.charAt(0))){
                        ShowStatus(Integer.parseInt(StudentName));
                    }else{
                        ShowStatus(StudentName);
                    }
                    break;
                
            
                default:                  
                    break loop;
            }

            System.out.println();
            System.out.println();


        }

        
        sc.close();
        DisconnectDB();

        System.out.println("Database Successfully Disconnected");


    }
    
}
 