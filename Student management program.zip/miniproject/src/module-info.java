/**
 * 
 */
/**
 * @author Dell
 *
 */
module miniproject {
	requires java.sql;
}